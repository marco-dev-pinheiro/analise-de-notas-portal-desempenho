/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion, AnimatePresence } from "motion/react";
import { 
  GraduationCap, 
  Search, 
  TrendingUp, 
  TrendingDown, 
  User, 
  CheckCircle2, 
  XCircle,
  BarChart3
} from "lucide-react";
import { useState, useMemo } from "react";

interface Student {
  name: string;
  grades: number[];
}

const INITIAL_DATA: Student[] = [
  { name: "Marcelo Barbosa", grades: [6.5, 8.3, 9.2, 7.2] },
  { name: "Rafaela Santos", grades: [8.3, 4.5, 7.5, 4.5] },
  { name: "Ronaldo Santos", grades: [7, 2.1, 8.9, 8.9] },
  { name: "Lucas Gabriel Ribeiro", grades: [5.9, 9.8, 6.4, 6.1] },
  { name: "Luana da Silva", grades: [9.2, 5.6, 3.1, 9.8] },
  { name: "Mariana Pereira", grades: [4.7, 1.2, 5.8, 5.4] },
  { name: "Maria Eduarda Farias", grades: [8.8, 7.7, 4.2, 10] },
  { name: "Fernando Henrique Silva", grades: [6.1, 6.9, 9.7, 2.3] },
  { name: "Pedro Henrique Souza", grades: [7.2, 3.4, 8, 6.7] },
  { name: "Ana Paula Oliveira", grades: [0, 0.5, 7.2, 8] },
  { name: "Natália Guimarães", grades: [5.5, 4.8, 5.1, 3.6] },
  { name: "João Vitor Ferreira", grades: [8, 8.9, 2.8, 0] },
  { name: "Rodrigo Almeida", grades: [7.9, 2.2, 6.9, 6.9] },
  { name: "Gustavo Carvalho", grades: [6.4, 9.1, 7.6, 4.3] },
  { name: "Leticia Costa", grades: [9.9, 1, 9.4, 7.8] },
  { name: "Aline da Rocha", grades: [8.5, 7.2, 5.7, 5] },
  { name: "Marcos Vinicius Lima", grades: [6.8, 3.3, 4.5, 8.3] },
  { name: "Carla Cristina Castro", grades: [0, 6, 5.1, 1.1] },
  { name: "Isabela da Costa", grades: [5.2, 5.1, 6.3, 9.1] },
  { name: "Bruna Oliveira", grades: [9, 2.5, 9.9, 7.6] }
];

export default function App() {
  const [searchTerm, setSearchTerm] = useState("");
  const PASS_GRADE = 7.0;

  const studentsWithAverages = useMemo(() => {
    return INITIAL_DATA.map(student => {
      const average = student.grades.reduce((a, b) => a + b, 0) / student.grades.length;
      return { 
        ...student, 
        average: parseFloat(average.toFixed(2)),
        isPassing: average >= PASS_GRADE
      };
    }).filter(s => s.name.toLowerCase().includes(searchTerm.toLowerCase()));
  }, [searchTerm]);

  const stats = useMemo(() => {
    const total = INITIAL_DATA.length;
    const passing = INITIAL_DATA.filter(s => (s.grades.reduce((a, b) => a + b, 0) / 4) >= PASS_GRADE).length;
    const avgScore = (INITIAL_DATA.reduce((acc, curr) => acc + (curr.grades.reduce((a, b) => a + b, 0) / 4), 0) / total).toFixed(2);
    
    return { passing, total, avgScore };
  }, []);

  return (
    <div className="min-h-screen bg-amber-50 text-slate-800 font-sans p-4 md:p-8">
      <div className="max-w-6xl mx-auto space-y-12">
        
        {/* Header section */}
        <header className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-center gap-5">
            <div className="w-16 h-16 bg-pink-500 rounded-2xl flex items-center justify-center shadow-lg transform -rotate-3 border-4 border-indigo-900">
              <GraduationCap className="w-8 h-8 text-white" id="header-icon" />
            </div>
            <div>
              <h1 className="text-4xl font-black tracking-tight text-indigo-900" id="app-title">NotaMaster</h1>
              <p className="text-indigo-600 font-bold uppercase tracking-widest text-xs" id="app-subtitle">Portal de Desempenho v2.0</p>
            </div>
          </div>

          <div className="flex flex-col md:flex-row gap-4">
            <div className="px-6 py-3 bg-white border-4 border-indigo-900 rounded-full font-black text-indigo-900 shadow-[4px_4px_0px_0px_rgba(49,46,129,1)] flex items-center gap-2">
              <div className="w-3 h-3 bg-teal-400 rounded-full animate-pulse" />
              Turma: 3º Ano B
            </div>
            <div className="relative group w-full md:w-64">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-indigo-900 group-focus-within:text-pink-500 transition-colors" />
              <input 
                type="text"
                id="search-input"
                placeholder="Buscar aluno..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-12 pr-4 py-3 bg-white border-4 border-indigo-900 rounded-3xl focus:outline-none focus:ring-0 focus:border-pink-500 transition-all shadow-[4px_4px_0px_0px_rgba(49,46,129,1)] font-bold text-indigo-900"
              />
            </div>
          </div>
        </header>

        {/* Dashboard stats in summary mode */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-indigo-900 rounded-[2.5rem] p-8 text-white flex flex-col gap-6 relative overflow-hidden shadow-xl">
            <div className="absolute -right-8 -top-8 w-32 h-32 bg-indigo-800 rounded-full opacity-50"></div>
            <div className="flex items-center gap-3">
              <User className="w-6 h-6 text-teal-400" />
              <h3 className="text-xl font-black uppercase tracking-tight">Estatísticas</h3>
            </div>
            <div className="flex flex-col gap-4">
              <div className="flex justify-between items-end border-b border-indigo-700 pb-3">
                <span className="text-indigo-300 font-bold text-xs uppercase tracking-widest">Total de Alunos</span>
                <span className="text-3xl font-black">{stats.total}</span>
              </div>
              <div className="flex justify-between items-end border-b border-indigo-700 pb-3">
                <span className="text-indigo-300 font-bold text-xs uppercase tracking-widest">Acima da Média</span>
                <span className="text-3xl font-black text-teal-400">{Math.round((stats.passing/stats.total)*100)}%</span>
              </div>
              <div className="flex justify-between items-end">
                <span className="text-indigo-300 font-bold text-xs uppercase tracking-widest">Média Geral</span>
                <span className="text-3xl font-black text-pink-400">{stats.avgScore.replace('.', ',')}</span>
              </div>
            </div>
          </div>

          <div className="md:col-span-2 flex flex-col gap-6">
            <div className="flex items-center justify-between px-2">
              <h2 className="text-2xl font-black text-indigo-900">Quadro de Notas</h2>
              <span className="bg-indigo-900 text-white px-4 py-1 rounded-full text-xs font-black uppercase tracking-widest">
                {studentsWithAverages.length} Alunos Filtrados
              </span>
            </div>
            
            <div className="space-y-4 max-h-[600px] overflow-y-auto pr-2 custom-scrollbar">
              <AnimatePresence mode="popLayout">
                {studentsWithAverages.map((student, index) => {
                  const initials = student.name.split(' ').map(n => n[0]).join('').slice(0, 2);
                  const avatarColors = ["bg-teal-400", "bg-pink-400", "bg-yellow-400", "bg-orange-400", "bg-indigo-400"];
                  const avatarColor = avatarColors[index % avatarColors.length];
                  
                  return (
                    <motion.div 
                      key={student.name}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                      transition={{ delay: index * 0.05 }}
                      className="bg-white border-4 border-indigo-900 rounded-3xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-6 shadow-[6px_6px_0px_0px_rgba(49,46,129,1)] hover:shadow-none hover:translate-x-1 hover:translate-y-1 transition-all"
                    >
                      <div className="flex items-center gap-4">
                        <div className={`w-14 h-14 ${avatarColor} rounded-2xl border-2 border-indigo-900 flex items-center justify-center font-black text-indigo-900 text-xl shadow-sm rotate-2`}>
                          {initials}
                        </div>
                        <div>
                          <div className="font-black text-xl text-indigo-900 leading-tight">{student.name}</div>
                          <div className="text-[10px] font-black uppercase text-slate-400 tracking-widest mt-1">ID: MATH-{(index+1000)}</div>
                        </div>
                      </div>
                      
                      <div className="flex flex-wrap gap-4 items-end justify-center">
                        <div className="flex gap-2">
                          {student.grades.map((grade, idx) => (
                            <div key={idx} className="flex flex-col items-center gap-1">
                              <span className="text-[9px] font-black uppercase text-slate-400">P{idx+1}</span>
                              <span className="bg-indigo-50 border-2 border-indigo-900 w-12 h-10 flex items-center justify-center rounded-xl font-black text-indigo-900 text-sm">
                                {grade.toFixed(1).replace('.', ',')}
                              </span>
                            </div>
                          ))}
                        </div>
                        
                        <div className={`ml-4 ${student.isPassing ? 'bg-teal-400' : 'bg-pink-400'} border-4 border-indigo-900 rounded-3xl px-8 py-3 flex flex-col items-center justify-center shadow-sm -rotate-1`}>
                          <span className="text-[10px] font-black uppercase text-indigo-900">Média</span>
                          <span className="text-3xl font-black text-indigo-900">
                            {student.average.toFixed(1).replace('.', ',')}
                          </span>
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </AnimatePresence>
              
              {studentsWithAverages.length === 0 && (
                <div className="py-20 text-center space-y-6 bg-white/50 border-4 border-dashed border-indigo-200 rounded-[3rem]">
                  <Search className="w-16 h-16 text-indigo-200 mx-auto" />
                  <p className="text-indigo-400 font-black text-xl uppercase tracking-tight">Fim de curso! Nenhum resultado.</p>
                  <button 
                    onClick={() => setSearchTerm("")}
                    className="px-8 py-3 bg-indigo-900 text-white rounded-full font-black uppercase text-xs tracking-widest hover:bg-pink-500 transition-colors"
                  >
                    Limpar Filtros
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <footer className="pt-12 flex flex-col md:flex-row justify-between items-center gap-6 text-indigo-900 opacity-60 border-t-4 border-indigo-900/10">
          <div className="font-black text-xs uppercase tracking-widest flex items-center gap-2">
            <span className="w-2 h-2 bg-pink-500 rounded-full" />
            © 2026 NotaMaster Academy Professional
          </div>
          <div className="flex gap-8 font-black uppercase text-[10px] tracking-widest">
            <a href="#" className="hover:text-pink-500 underline underline-offset-4 decoration-2">Configurações</a>
            <a href="#" className="hover:text-pink-500 underline underline-offset-4 decoration-2">Exportar Dados</a>
            <a href="#" className="hover:text-pink-500 underline underline-offset-4 decoration-2">Suporte Técnico</a>
          </div>
        </footer>
      </div>
    </div>
  );
}

// Removing unused StatCard component as it's been integrated into the new layout
